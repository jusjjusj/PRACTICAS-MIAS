package controlador;

import java.sql.*;
import java.util.ArrayList;
import java.util.Hashtable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.EmpleadoActionForm;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.DynaActionForm;

public class EmpleadoAction extends org.apache.struts.action.Action
implements org.apache.struts.action.PlugIn {

    private static final String SUCCESS = "success";

   
    @Override
    public ActionForward execute(ActionMapping actionMapping, ActionForm actionForm,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        
        ActionForward retValue = null;
        try{
            DynaActionForm formulario = (DynaActionForm) actionForm;
            String oficio = formulario.get("datosEmpleados").toString();
            
            ArrayList<EmpleadoActionForm> listaempleados = new ArrayList<EmpleadoActionForm>();    
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
            Connection cn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","info8314");
           
            Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery("select apellido, oficio, salario from emp where oficio='"+oficio+"'");

            ArrayList result =  new ArrayList();

            
            while (rs.next()) {
                EmpleadoActionForm emp = new EmpleadoActionForm();
                emp.setApellido(rs.getString("APELLIDO"));
                emp.setOficio(rs.getString("OFICIO"));
                emp.setSalario(Integer.parseInt(rs.getString("SALARIO")));
                listaempleados.add(emp);
                    
                        
            }            
            request.setAttribute("datosempleados",listaempleados);
 
            
            retValue= actionMapping.findForward("correcto"); 
         } catch (SQLException ex) {
            // recuperamos acceso al JSP de origen
             retValue = actionMapping.getInputForward();
        }    
        return retValue; // redirigimos a la presentacion
    }
    
   @Override
    public void destroy() 
    {

    }

   @Override

   
    public void init(org.apache.struts.action.ActionServlet actionServlet, 
         org.apache.struts.config.ModuleConfig moduleConfig) throws 
           javax.servlet.ServletException 
    {  
        
        try 
        {
            Hashtable listaoficios = new Hashtable();
            EmpleadoActionForm emp = new EmpleadoActionForm();
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
            Connection cn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","info8314");
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery("select distinct(oficio) from emp");
            while (rs.next())
            {
                emp.setOficio(rs.getString("OFICIO"));
                listaoficios.put(rs.getString("OFICIO"),rs.getString("OFICIO"));
            }
             
            actionServlet.getServletContext().setAttribute("tablaOficios",listaoficios);  
                      
        } catch (SQLException ex) {
            System.out.println("Excepcion " + ex.toString());
        }
        
    }
}    
