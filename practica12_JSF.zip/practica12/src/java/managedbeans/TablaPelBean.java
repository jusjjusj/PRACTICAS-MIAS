package managedbeans;

import java.sql.*;
import java.util.*;

/**
 *
 * @author Administrador
 */

public class TablaPelBean {
    private String buscar;
    private List<Pelicula> listapeliculas;
    private String mensaje;
    Connection cn = null;

    public TablaPelBean() {
        this.listapeliculas = new ArrayList<Pelicula>(); 
    }
    
    
    public void conectarSQL() throws SQLException
    {
        cn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","info8314");
    }
    
    public void recuperarPeliculas()
    {
        try
        {
            String consulta = "SELECT * FROM peliculas where TITULO like ?";
            this.conectarSQL();
            PreparedStatement pst = this.cn.prepareCall(consulta);
            pst.setString(1, buscar + "%");
            ResultSet rs = pst.executeQuery();
            setListapeliculas(new ArrayList<Pelicula>());
            while (rs.next())
            {
                Pelicula d = new Pelicula();
                d.setPrecio(rs.getInt(("PRECIO")));
                d.setCartel(rs.getString(("FOTO")));
                d.setTitulo(rs.getString(("TITULO")));
                d.setDirector(rs.getString(("DIRECTOR")));
                getListapeliculas().add(d);
            }
            rs.close();
        }catch (Exception ex)
        {
            this.mensaje = "Error al recuperar peliculas " + ex;
        }
        
    }

    public String getBuscar() {
        return buscar;
    }
    
    public void setBuscar(String buscar) {
        this.buscar = buscar;
    }  
    

    public List<Pelicula> getListapeliculas() {
        return listapeliculas;
    }

    public void setListapeliculas(List<Pelicula> listapeliculas) {
        this.listapeliculas = listapeliculas;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}
