package customtags;

public class TagsPersonalizados {
    
    public static boolean contains(String[] s, String input) {
          if (s != null) {
               for (String i : s) {
                    if (i.equals(input)) {
                         return true;
                    }
               }
          }
          return false;
     }
    
}