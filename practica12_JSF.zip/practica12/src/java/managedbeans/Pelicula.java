package managedbeans;

/**
 *
 * @author Administrador
 */
public class Pelicula {
    private String cartel;
    private String titulo;
    private String director;
    private int precio;

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int numero) {
        this.precio = numero;
    }

    public String getCartel() {
        return cartel;
    }

    public void setCartel(String nombre) {
        this.cartel = nombre;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String localidad) {
        this.titulo = localidad;
    }
    
    public String getDirector() {
        return director;
    }

    public void setDirector(String localidad) {
        this.director = localidad;
    }
}

