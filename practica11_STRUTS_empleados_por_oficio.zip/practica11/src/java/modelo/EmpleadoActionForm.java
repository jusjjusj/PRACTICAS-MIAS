package modelo;

public class EmpleadoActionForm  {

 
private String apellido;
private String oficio;
private int salario;


   

public String getApellido(){ return apellido;}
public String getOficio(){ return oficio;}


public int getSalario(){ return salario;}


public void setApellido(String apellido){ this.apellido = apellido;}
public void setOficio(String oficio){ this.oficio = oficio;}

public void setSalario(int salario){ this.salario = salario;}




  
}
