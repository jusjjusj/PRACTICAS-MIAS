/*
DEFINICION DE LA TABLA CLIENTE, SECUENCIA AUTOINCREMENTAL Y PROCEDIMIENTO DE ALTA

CREATE TABLE CLIENTE(
	CLIENTE_NO NUMBER(4,0)
		CONSTRAINT CLIENTE_PRIMARY_KEY PRIMARY KEY,
	NOMBRE VARCHAR2(15)
		NOT NULL,
	APELLIDO1 VARCHAR2(15)
		NOT NULL,
	APELLIDO2 VARCHAR2(15)
		NOT NULL,
	DIRECCION VARCHAR2(50),
	SEXO VARCHAR2(1)
		CONSTRAINT CLIENTE_CHK_SEXO CHECK(SEXO IN('M','F')),
	CIUDAD VARCHAR2(22)
		CONSTRAINT CLIENTE_CHK_CIUDAD CHECK(CIUDAD IN('ALAVA','ALBACETE','ALICANTE','ALMERIA','ASTURIAS','AVILA','BADAJOZ',
					'BARCELONA','BURGOS','CACERES','CADIZ','CANTABRIA','CASTELLON','CEUTA','CIUDAD REAL',
					'CORDOBA','CORUÑA, A','CUENCA','GIRONA','GRANADA','GUADALAJARA','GUIPUZCOA','HUELVA',
					'HUESCA','ILLES BALEARS','JAEN','LEON','LLEIDA','LUGO','MADRID','MALAGA','MELILLA',
					'MURCIA','NAVARRA','OURENSE','PALENCIA','PALMAS, LAS','PONTEVEDRA','RIOJA, LA',
					'SALAMANCA','SANTA CRUZ DE TENERIFE','SEGOVIA','SEVILLA','SORIA','TARRAGONA','TERUEL',
					'TOLEDO','VALENCIA','VALLADOLID','VIZCAYA','ZAMORA','ZARAGOZA')),
	SO VARCHAR2(25),
	COMENTARIOS VARCHAR2(200)
);



CREATE SEQUENCE cliente_cod
START WITH 1
INCREMENT BY 1;


CREATE OR REPLACE PROCEDURE ALTACLIENTE
(p_nombre cliente.nombre%type,
p_apellido1 cliente.apellido1%type,
p_apellido2 cliente.apellido2%type,
p_direccion cliente.direccion%type,
p_sexo cliente.sexo%type,
p_ciudad cliente.ciudad%type,
p_so cliente.so%type,
p_comentarios cliente.comentarios%type) as

begin
        INSERT INTO CLIENTE VALUES
        (cliente_cod.nextval, p_nombre, p_apellido1,
        p_apellido2, p_direccion, p_sexo,
        p_ciudad, p_so, p_comentarios);
COMMIT; 
end;

*/
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Administrador
 */
@WebServlet(urlPatterns = {"/servlet"})
public class servlet extends HttpServlet {
  
    private String join(String[] input, String delimiter) {     
        if (input != null) {
            StringBuilder sb = new StringBuilder();
            for (String value : input) {
                sb.append(value);
                sb.append(delimiter);
            }
            int length = sb.length();
            if (length > 0) {
                  // Remove the extra delimiter
               sb.setLength(length - delimiter.length());
             return sb.toString();
            }
        }
        return "";
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter pw = response.getWriter();
        try {
            
            String nombre = request.getParameter("nombre");
            String apellido1 = request.getParameter("apellido1");
            String apellido2 = request.getParameter("apellido2");
            String domicilio = request.getParameter("domicilio");
            String ciudad = request.getParameter("ciudad");
            String sexo = request.getParameter("sexo");
            String[] so = request.getParameterValues("so");
            String comentarios = request.getParameter("comentarios");
            
            
            response.setContentType("text/html");
            
            DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
            
            Connection cn = DriverManager.getConnection
                          ("jdbc:oracle:thin:@localhost:1521:XE","system","info8314");
            
            CallableStatement cs = cn.prepareCall("{call ALTACLIENTE(?,?,?,?,?,?,?,?)}");

            cs.setString(1, nombre);
            cs.setString(2, apellido1);
            cs.setString(3, apellido2);
            cs.setString(4, domicilio);
            cs.setString(5, sexo);
            cs.setString(6, ciudad);
            cs.setString(7, join(so,","));
            cs.setString(8, comentarios);
            
            cs.executeUpdate();
            
                    pw.println("<p>Sr/a " + nombre + " " + apellido1 + " " + apellido2 + " acaba de almacenar sus datos en nuestra base de datos</p>");
            
            
                    SimpleDateFormat formateador = new SimpleDateFormat("dd 'de' MMMM 'de' yyyy", new Locale("es"));        
                    pw.println("<style type=\"text/css\">.Rojo {color: #F00;}</style><p><strong class='rojo'>Dato insertado a fecha " + formateador.format(new Date())+"</strong></p>");
                    
              cn.close();
     
        } catch (Exception ex) {
            
                    pw.println("<style type=\"text/css\">.Rojo {color: #F00;}</style><p><strong class='rojo'>ERROR: Registro NO insertado</strong></p>");
                
 
        }
        
        pw.println("<p><a href='index.html'>Volver</a></p>");
            pw.close();
    }
}
