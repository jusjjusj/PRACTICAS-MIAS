/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package customtags;

import java.sql.*;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

/**
 *
 * @author Administrador
 */
public class Resultados_RM extends TagSupport {
    
    //DECLARACIÓN DE VARIABLES 

    //Variables de conexión a la base de datos. 
    Connection cn = null; 
    Statement s = null; 
    boolean conectado; // Conectado si o no ? 

 

    //Datos de la conexión 
    public String dbURL = ""; 
    public String pwd = ""; 
    public String usuario = ""; 

    private String lugar, categoria;
    
    
    public Resultados_RM() throws Exception { 
        usuario = "system"; 
        pwd = "info8314"; 
        dbURL = "jdbc:oracle:thin:@localhost:1521:XE"; 
        Conectar(); 

    } 
    public void Conectar() throws Exception { 
        conectado = true; 
        try { 
            Class.forName("oracle.jdbc.driver.OracleDriver"); 
            cn = DriverManager.getConnection(dbURL, usuario, pwd); 
            s = cn.createStatement(); 
        }
        catch(Exception e) { 
            conectado = false; 
            throw e; 
        } 
    } 
     
    public void CerrarConexion() { 
        try { 
            s.close(); 
            cn.close(); 
        } 
        catch(Exception e){} 
    }
    
    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }
    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    @Override
    public int doStartTag() throws JspTagException {
        return SKIP_BODY;
    }
    
    @Override    
    public int doEndTag() throws JspTagException {
        try {
           ResultSet rs = s.executeQuery("SELECT equipo1, equipo2, resultado FROM Resultados_RM WHERE lugar='" + getLugar()
           +"' AND categoria='" + getCategoria() + "'");
           
           String tabla = "<table border='1' cellspacing='0' cellpadding='3' align='center' width='100%'>";
           tabla += "<tr bgcolor='#00FF00'><th>Equipo1</th><th>Equipo2</th><th>Resultados</th></tr>";
           while (rs.next()) {
               tabla += "<tr bgcolor='#FFFF00' align='center'>";
               tabla += "<td>" + rs.getString("equipo1") + "</td>";
               tabla += "<td>" + rs.getString("equipo2") + "</td>";
               tabla += "<td>" + rs.getString("resultado") + "</td>";  
               tabla += "</tr>";
           }
           tabla += "</table>";
           pageContext.getOut().write(tabla);
           rs.close();
       }
       catch (Exception ex) {
           CerrarConexion();
           throw new JspTagException("Excepcion " + ex.toString());
       }
       return EVAL_PAGE;
   }
}