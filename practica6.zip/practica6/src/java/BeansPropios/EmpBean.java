package BeansPropios;

import java.util.*; 
import java.io.*; 
import java.sql.*;

/**
 *
 * @author Administrador
 */
public class EmpBean {
//DECLARACIÓN DE VARIABLES 

//Variables de conexión a la base de datos. 
Connection cn = null; 
 Statement s = null; 
boolean conectado; // Conectado si o no ? 

 

//Datos de la conexión 
public String dbURL = ""; 
 public String pwd = ""; 
public String usuario = ""; 


 
 // Variables globales para saber si existe un elemento o no y 
 // auxiliar para guadar el target del enlace. 
boolean encontrado = false; 
String strTarget = ""; 


//Variable para guardar la cadena que mostrará el pie con los 
//número de página. 
 String strCadenaPaginas = ""; 

 //Variables para los colores, está inicializados a mi gusto.
 // Cambialos si lo deseas.
String ColorFondoTabla  = "#000066";
String ColorEncabezadoTabla = "#CCCCCC";
String ColorPieTabla    = "#DDDDDD";
String ColorTextoEncabezadoTabla = "#000000";
String ColorFilaImpar   = "#FFFFFF";
String ColorFilaPar = "#EFEFEF";
String ColorFondoTitulo = "#000066";
String ColorTextoTitulo = "#FFFFFF";
String ColorTextoFilas  = "#123456";
      
  
 
 
 //Estas son genericas para el formateado de los resultados, como 
 // el ancho de la tabla, el tamaño de la letra, el tipo de 
 // letra etc. 
 String strAnchoTabla = "70%"; 
 String strTamanoLetra = "2"; 
String strMensaje_no_hay_resultados = "Sin datos"; 
 String strHtml_no_resultados = ""; 
 String strTitulo_Rejilla = "Consulta"; 
 String strFaceLetra = "Verdana"; 
boolean bl_mostrar_paginaXdeY = false; 
 boolean bl_mostrar_paginas = true; 

  

 // Quizá las más importantes son estas variables que son Arrays 
 // de dos dimensiones. Se explicarán en detalle más adelante. 
  
 String arTitulo_Campos[]; 
 String arOrdenar_Campos[][]; 
 String arNombres_Campos[]; 

 

 //Necesitamos una variable para saber por qué campo vamos a 
 // contar el número de registros que hay en la consulta. 
 String strCampoContarRegistros = ""; 

 

 //Al hacer clic en siguiente página o en anterior, hay que 
 //decirle al Bean el nombre la página.Se inicializa a prueba.jsp 
 // pero es obligatorio poner el adecuado si quieres que 
 // funcione. 
 String que_pagina = "ejemplo_paginacion.jsp"; 

 

 //Variables que formaran la consulta. Muy importantes. 
 String strSelect = ""; 
 String strFrom = ""; 
 String strGroupBy = ""; 
 String strWhere = ""; 
 String strOrderBy = ""; 
 String enlace1,enlace2 = ""; 
boolean hay_orderby = false; 


//Variable para pasarle otros parámetros si hacen falta. 
 // al estilo de “&miparam1=valor1&miparam2=valor2” 
 String strOtrosParametros = "&"; 
 

 // Típica variable que me ayudará contar registros. 
int contador = 1; 


//Cuantos registros por página, se inicializa a 10. 
// Pero se puede cambiar claro. 
 int registros = 3; 


 //Esta variable, me dice en qué registro estamos, para mostrar 
 //el resto a partir de él. 
 int RegistroActual = 1; 

public EmpBean() throws Exception 

 { 
 usuario = "system"; 
 pwd = "info8314"; 
 dbURL = "jdbc:oracle:thin:@localhost:1521:XE"; 
 Conectar(); 

 } 
     public void Conectar() throws Exception 
 { 
 conectado = true; 
 try { 
 Class.forName("oracle.jdbc.driver.OracleDriver"); 
 cn = DriverManager.getConnection(dbURL, usuario, pwd); 
 s = cn.createStatement(); 
 }catch(Exception e) 
 { 
 conectado = false; 
 throw e; 
 } 
 } 
     
     public void Hacer_CadenaNoDatos() 
 { 

 strHtml_no_resultados= "<P>"; 
strHtml_no_resultados+= strMensaje_no_hay_resultados; 
 strHtml_no_resultados+= " <p>&nbsp;</p> "; 

 } 
    
     public boolean TieneRegistros() 
{ 

 boolean bolTiene = false; 
 int intTotalReg = 0; 
 try { 
 Statement s1 = cn.createStatement(); 
 ResultSet rsTotalRegistros = s1.executeQuery("select count(" + strCampoContarRegistros +") AS TOTAL_REGISTROS " + strFrom + strWhere); 


 if (rsTotalRegistros != null){ 
 rsTotalRegistros.next(); 
 intTotalReg = rsTotalRegistros.getInt("TOTAL_REGISTROS"); 
 if (intTotalReg>0) bolTiene=true; 
 } 
 rsTotalRegistros.close(); 
 s1.close(); 
 }catch(Exception j){} 
 return bolTiene; 
} 
public void CerrarConexion() 
 { 
 try { 
 s.close(); 
 cn.close(); 
 } catch(Exception e){} 
 }

public void setTextoNoHayResultados(String v_mensaje){ 
 strMensaje_no_hay_resultados = v_mensaje; 
 } 

 public void setOtrosParametros(String v_otros){ 
 strOtrosParametros = v_otros; 
 } 

 public void setAnchoTabla(String strAncho){ 
 strAnchoTabla = strAncho; 
 } 

public void setColorFondoTabla (String RGBColor){
ColorFondoTabla = RGBColor;
}
public void setColorEncabezadoTabla (String RGBColor){
ColorEncabezadoTabla = RGBColor;
}

 public void setTipoLetra (String strTipoLetra){ 
 strFaceLetra = strTipoLetra; 
 } 

public void setColorPieTabla (String RGBColor){
ColorPieTabla = RGBColor;
}
 public void setTamanoLetra (String tamanio){ 
 strTamanoLetra = tamanio; 
 } 

public void setColorTextoEncabezadoTabla (String RGBColor){
ColorTextoEncabezadoTabla = RGBColor;
}
public void setColorFilaImpar (String RGBColor){
ColorFilaImpar = RGBColor;
}
public void setColorFilaPar (String RGBColor){
ColorFilaPar = RGBColor;
}
public void setColorTextoFilas (String RGBColor){
ColorTextoFilas = RGBColor;
}
public void setColorTextoTitulo (String RGBColor){
ColorTextoTitulo = RGBColor;
}
public void setRegistros_Pagina(int intRegistros){ 
 registros = intRegistros; 
 } 

 public void setRegistroActual(int intRegistro){ 
 RegistroActual = intRegistro; 
 } 

 public void setTitulos_Campos(String array_titulos_campos[]){
 arTitulo_Campos = array_titulos_campos; 
 } 

 public void setOrdenar_Campo(String array_ordenar_campos[][]){
 arOrdenar_Campos = array_ordenar_campos; 
 } 

 

 public void setTitulo_Rejilla(String strTitulo){ 
 strTitulo_Rejilla = strTitulo; 
 } 


 

 public void setPagina(String strPagina){ 
 que_pagina = strPagina; 
 } 

 

 public void setCampoContarRegistros(String Campo){ 
 strCampoContarRegistros = Campo; 
 } 

 public String getCampoContarRegistros(){ 
 return strCampoContarRegistros; 
 } 

 

 public void setNombres_Campos(String array_nombres_campos[]){ 
 arNombres_Campos = array_nombres_campos; 
 } 

 public void setMostrar_paginaXdeY(boolean SioNo){ 
 bl_mostrar_paginaXdeY = SioNo; 
 } 

 

 public void setMostrar_Paginas(boolean SioNo){ 
 bl_mostrar_paginas = SioNo; 
 } 

 public void setSelect(String strSelect1){ 
 strSelect = strSelect1; 
 } 

 public void setFrom(String strFrom1){ 
 strFrom = strFrom1; 
 } 

 public void setGroupBy(String strGroupBy1){ 
 strGroupBy = strGroupBy1; 
 } 

 public void setWhere(String strWhere1){ 
 strWhere = strWhere1; 
} 

 public void setOrderBy(String strOrderBy1){ 
 strOrderBy = strOrderBy1; 
 } 

 public String Mostrar_Registros() throws SQLException{ 

String strsql = ""; 
String strcadena = ""; 
int contador = 1; 
int i = 0; 


// CREO LA SELECT 
 strsql=strSelect+" from (select tablaemp.*, ROWNUM rnum from ("; 
 strsql+=strSelect+strFrom+strOrderBy+") tablaemp where ROWNUM <" ; 
 strsql+=RegistroActual+registros+") where rnum >=" + RegistroActual; 


 try { 
 


    // ***************************************** 
    // SACA EL NUMERO DE REGISTROS DE LA TABLA 
    // ***************************************** 
    int intTotalReg = 0; 

    Statement s1 = cn.createStatement(); 
    
    ResultSet rsTotalRegistros = s1.executeQuery("select count(" + strCampoContarRegistros +") AS TOTAL_REGISTROS " + strFrom + strWhere ); 
    if (rsTotalRegistros != null){ 
        rsTotalRegistros.next(); 
        intTotalReg = rsTotalRegistros.getInt("TOTAL_REGISTROS"); 
    } 

    // CALCULA EL NUMERO DE PAGINAS QUE HAY EN LA SELECT 
    // *************************************************** 

    int Total_Paginas = 0; 
    if (intTotalReg > 0){ 
        Total_Paginas = intTotalReg / registros; 
        if (intTotalReg % registros >0) Total_Paginas ++; 
    } 

    rsTotalRegistros.close(); 
    s1.close(); 

 

    // FIN DEL REGISTROS DE LA TABLA 
    // ***************************** 

    if (intTotalReg >0 && (RegistroActual >=1) ) 
    { 
        strcadena+="<table width='"+strAnchoTabla+"' border='0' cellspacing='2' cellpadding='1' align='center'>"; 
        strcadena+=" <tr bgcolor='"+ColorFondoTabla+"'> "; 
        strcadena+=" <td> "; 
        strcadena+="<table width='100%' border='0' cellspacing='1' cellpadding='3' align='center'>"; 
        strcadena+=" <tr bgcolor='"+ColorFondoTitulo+"'> "; 

 
    
        strcadena+=" <td colspan='"+arNombres_Campos.length+"'><b><font size='"+strTamanoLetra+"' face='"+strFaceLetra+"' color='"+ColorTextoTitulo+"'><b>" + strTitulo_Rejilla +intTotalReg+"</b></font></b></td>"; 
         
        strcadena+="</tr>"; 
        strcadena+=" <tr> "; 
        //el order by pasado por el array 
        hay_orderby=false; 
        for (int k=0;k<arTitulo_Campos.length;k++){ 
            strcadena+="<td bgcolor='" +ColorEncabezadoTabla+"'><font size='"+strTamanoLetra+"' face='"+strFaceLetra+"' color='"+ColorTextoEncabezadoTabla+"'><b>" + arTitulo_Campos[k] + "</b></font>";      
            try { 
                for (int mm=0;mm<arOrdenar_Campos.length;mm++){ 
                    if (arTitulo_Campos[k].equals(arOrdenar_Campos[mm][0])){ 
                       strcadena+="  <a href="+que_pagina+"?orderby=order%20by%20"+arOrdenar_Campos[mm][1]+strOtrosParametros+"><img width=\"9\" height=\"9\" align=\"absmiddle\" alt=\"Ordenar Ascendente\" border=\"0\" src=\"images/order_down.gif\"></A>&nbsp;<a href="+que_pagina+"?orderby=order%20by%20"+arOrdenar_Campos[mm][1]+"%20DESC"+strOtrosParametros+"><img border=\"0\" width=\"9\" height=\"9\" align=\"absmiddle\" src=\"images/order_up.gif\" alt=\"Ordenar descendentemente\"></A>"; 
                    } 
                } 
            }catch(Exception e){ } 
            strcadena+="</td>"; 
        } 
        strcadena+=" </tr>"; 

        
        
        
    } 
    
    ResultSet rs = s.executeQuery(strsql); 
    
    //strcadena+="<tr><td>"+strsql+"</td></tr>";

    if (intTotalReg >0 && (rs.next() || RegistroActual >=1) ) 
    { 
        
        int contador_registros = 1; 
        int pagina = 1; 
        int registros_anteriores = 1; 

        //********************************************************************** 
        //SABER LOS REGISTROS ANTERIORES Y Y LA PAGINA EN LA QUE ESTA EL USUARIO 
        //********************************************************************** 

        while (registros_anteriores < RegistroActual) {  
            registros_anteriores++; 

            //CALCULA QUE PAGINA SE ESTA MOSTRANDO 
            //************************************** 

            if (contador_registros >= registros) { 
                contador_registros = 0; 
                pagina++; //VARIABLE CUYO VALOR ES LA PAGINA EN LA QUE EST\u00c1
            } 
            contador_registros++; 
        } 

        //********************** 
        //PAGINAS DE LA CONSULTA 
        //********************** 

        int inicio = 1; 

        // SE CALCULA EN QUE PAGINA DEBE EMPEZAR LA CADENA DE PAGINAS 
        // ********************************************************** 

        if ( pagina > 10 ) 
            inicio = pagina - 5; 
        else 
            if (pagina==10) inicio = 9; 

        int contador_paginas = 1; 

 

        // HAGO LA CADENA QUE SIRVE PARA MOSTRAR LAS PAGINAS 
        // *************************************************** 

        for (int y=inicio;y<=Total_Paginas;y++){ 
            if (y != pagina) 
                strCadenaPaginas+="<a href='" +que_pagina +"?posicion=" + String.valueOf((y*registros)+1-registros)+"&orderby="+strOrderBy+strOtrosParametros+"'>"; 
            else 
                strCadenaPaginas+="<b><font size='"+strTamanoLetra+"' face='"+strFaceLetra+"'>["; 

            strCadenaPaginas+=y; 

            if (y != pagina) 
                strCadenaPaginas+="</a>"; 
            else 
                strCadenaPaginas+="]</font></b>"; 


            if (y !=Total_Paginas) 
                strCadenaPaginas+=" "; 
            contador_paginas++; 
            if (contador_paginas >10) break;

        } 

        // REGISTROS DE LA CONSULTA 
        // *********************** 

        do {
            if (i==0){ 
                strcadena+="<tr bgcolor='" + ColorFilaImpar +"'>"; 
                i=1; 
            } 
            else { 
                strcadena+="<tr bgcolor='" + ColorFilaPar + "'>"; 
                i=0; 
            } 

            for (int j=0;j<arNombres_Campos.length;j++){ 
                
                // SE IMPRIME LA FILA CON EL VALOR 
                strcadena+="<td><font size='"+strTamanoLetra+"' face='"+strFaceLetra+"' color='"+ColorTextoFilas+"'>" +  rs.getString(arNombres_Campos[j]) +"</font></td>"; 
            } 
            
            strcadena+="</tr>"; 
            contador++; 
        } while (rs.next());

    
    //PIE DE LA TABLA 1 --> PAGINA 1 DE n 
    //************************************* 
    if (bl_mostrar_paginaXdeY){
        strcadena+=" <tr> ";
        strcadena+="<td colspan='"+ arTitulo_Campos.length+1 +"' bgcolor='" +ColorPieTabla+"'><font size='"+strTamanoLetra+"' face='"+strFaceLetra+"' color='"+ColorTextoEncabezadoTabla+"'>P\u00e1gina " + pagina + " de " + Total_Paginas+"</font></td>";
        strcadena+="</tr> ";
    }
    //PIE DE LA TABLA --> P\u00e1gina : 1 2 3 4 5 6 7 8 9 ..... n
    //*********************************************************
    if ((bl_mostrar_paginas) && (Total_Paginas >=pagina)) {
        strcadena+=" <tr> ";
        strcadena+="<td colspan='"+ arTitulo_Campos.length+1+"' bgcolor='" +ColorPieTabla+"' align='center'><font size='"+strTamanoLetra+"' face='"+strFaceLetra+"' color='"+ColorTextoEncabezadoTabla+"'>" + strCadenaPaginas + "</font></td>";
        strcadena+="</tr> "; }
        strcadena+="</table>";
        strcadena+=" </td></tr></table>";
        // ***********************************************
        // SE CALCULA SI HAY QUE PONER ANTERIOR Y/o SIGUIENTE 
        // *********************************************** 
        String StrNavegacion = "";
        StrNavegacion+= "<table width='508' border='0' cellspacing='2' cellpadding='1' align='center'>";
        StrNavegacion+= "<tr align='center'> "; 
        if (RegistroActual >= registros + 1){
            StrNavegacion+= "<td width='220'> "; 
            StrNavegacion+= "<div align='right'><a href='"+que_pagina+"?posicion="+String.valueOf(RegistroActual- registros)+"&orderby="+strOrderBy+strOtrosParametros+"'> ";
            StrNavegacion+= "<font size='"+strTamanoLetra+"' face='"+strFaceLetra+"' >Anterior <img src='images/back.gif' border='0' alt='"+registros+" registros anteriores'></font></a> </div>";
            StrNavegacion+= "</td>"; 
        } else {
            StrNavegacion+= "<td width='220'>\u00a0\u00a0&nbsp;</td>";
        }
        StrNavegacion+= "<td width='220'>\u00a0\u00a0&nbsp;</td>";
        if ( (contador - 1 < intTotalReg) && (RegistroActual == 1)){
            StrNavegacion+= "<td ' width='220'>"; 
            StrNavegacion+= "<div align='left'><a href='"+que_pagina+"?posicion="+String.valueOf(RegistroActual+registros) +"&orderby="+strOrderBy+strOtrosParametros+"'>";
            StrNavegacion+= "<font size='"+strTamanoLetra+"' face='"+strFaceLetra+"'>Siguiente <img src='images/next.gif' border='0' alt='"+registros+" registros siguientes'></font></a> </div>";
            StrNavegacion+= "</td>";
        } else {
            if (RegistroActual - 1 + contador - 1 < intTotalReg){
                StrNavegacion+="<td width='220'> "; 
                StrNavegacion+= "<div align='left'><a href='" + que_pagina+"?posicion="+String.valueOf(RegistroActual+registros)+"&orderby="+strOrderBy+strOtrosParametros+"'> ";
                StrNavegacion+= "<font size='"+strTamanoLetra+"' face='"+strFaceLetra+"' >Siguiente <img src='images/next.gif' border='0' alt='"+registros+" registros siguientes'></font></a> </div>";
                StrNavegacion+= "</td>"; 
            } else {
                StrNavegacion+= "<td >\u00a0&nbsp;</td> "; 
            }
        }
        StrNavegacion+= "</tr>";
        StrNavegacion+= "</table>"; 
        strcadena+=StrNavegacion;
        
  } else{
        Hacer_CadenaNoDatos();
        strcadena = strHtml_no_resultados; 
  }
  rs.close();
 
}
 catch(Exception e) {
        strMensaje_no_hay_resultados = "<P><b><font size='3' face='"+strFaceLetra+"' color='#ff1111'>Se ha producido el siguiente error:</font></b><P><font size='"+strTamanoLetra+"' face='"+ strFaceLetra + "' color='"+ ColorTextoEncabezadoTabla+"'>" + e + "</p>";
        Hacer_CadenaNoDatos();
        //strMensaje_no_hay_resultados = "<p><b>Se ha producido un error:</b><p>"+e+"</p>";
        strcadena = strHtml_no_resultados;
        e.printStackTrace();
    }
    
    return strcadena; 
    
 }
} 